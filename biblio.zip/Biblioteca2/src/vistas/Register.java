package vistas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import java.awt.Color;

public class Register {

	private JFrame frame;
	private JTextField textCorreo;
	private JTextField textcontrasena;
	private JTextField textrpContrasena;
	private JFrame login;
	/**
	 * Launch the application.
	 */
/**	
 
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Register window = new Register();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
**/
	
	/**
	 * Create the application.
	 */
	public Register(JFrame log) {
		
		initialize(log);
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(JFrame log) {
		frame = new JFrame();
		frame.setBounds(100, 100, 736, 533);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		login = log;
		
		textCorreo = new JTextField();
		textCorreo.setBounds(208, 154, 270, 31);
		frame.getContentPane().add(textCorreo);
		textCorreo.setColumns(10);
		
		JLabel lblCorreo = new JLabel("Correo");
		lblCorreo.setForeground(Color.LIGHT_GRAY);
		lblCorreo.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 32));
		lblCorreo.setBounds(275, 105, 123, 39);
		frame.getContentPane().add(lblCorreo);
		
		textcontrasena = new JTextField();
		textcontrasena.setBounds(208, 269, 270, 31);
		frame.getContentPane().add(textcontrasena);
		textcontrasena.setColumns(10);
		
		JLabel lblContrasena = new JLabel("Contrase\u00F1a");
		lblContrasena.setForeground(Color.LIGHT_GRAY);
		lblContrasena.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 32));
		lblContrasena.setBounds(237, 228, 211, 31);
		frame.getContentPane().add(lblContrasena);
		
		textrpContrasena = new JTextField();
		textrpContrasena.setBounds(208, 392, 270, 31);
		frame.getContentPane().add(textrpContrasena);
		textrpContrasena.setColumns(10);
		
		JButton btnlogearse = new JButton("Iniciar");
		btnlogearse.setForeground(Color.DARK_GRAY);
		btnlogearse.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnlogearse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				login.setVisible(true);
				frame.dispose();
			}
		});
		btnlogearse.setBounds(8, 10, 110, 55);
		frame.getContentPane().add(btnlogearse);
		
		JButton btnRegistrarse = new JButton("Registrarse");
		btnRegistrarse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String contra = textcontrasena.getText();
				String rpContra = textrpContrasena.getText();
				if(contra!=null && rpContra!=null) {
					if(contra.equals(rpContra)) {
						try {
							String usu = textCorreo.getText();
				            FileWriter fileWriter = new FileWriter("usuario.txt",true);
				            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
				            String usuario = usu+","+contra;
				            bufferedWriter.write(usuario);
				            bufferedWriter.newLine();

				            bufferedWriter.close();
				        } catch (IOException e2) {
				            e2.printStackTrace();
				            JOptionPane.showMessageDialog(frame, "Error inesperado", "Error",
									JOptionPane.ERROR_MESSAGE);
				        }
						JOptionPane.showMessageDialog(frame, "Registrado correctamente", "Correcto",
								JOptionPane.INFORMATION_MESSAGE);
					}else {
						JOptionPane.showMessageDialog(frame, "Las contrase�as no coinciden", "Error",
								JOptionPane.ERROR_MESSAGE);
					}
				}
				
			}
		});
		btnRegistrarse.setForeground(Color.DARK_GRAY);
		btnRegistrarse.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnRegistrarse.setBounds(275, 433, 158, 55);
		frame.getContentPane().add(btnRegistrarse);
		
		JLabel lblrpcontrasena = new JLabel("Repita Contrase\u00F1a");
		lblrpcontrasena.setForeground(Color.LIGHT_GRAY);
		lblrpcontrasena.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 32));
		lblrpcontrasena.setBounds(188, 342, 304, 40);
		frame.getContentPane().add(lblrpcontrasena);
		
		JLabel lblTitulo = new JLabel("Registro");
		lblTitulo.setForeground(Color.LIGHT_GRAY);
		lblTitulo.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 40));
		lblTitulo.setBounds(237, 17, 225, 55);
		frame.getContentPane().add(lblTitulo);
		
		JLabel lblfondo = new JLabel("");
		lblfondo.setIcon(new ImageIcon(Register.class.getResource("/imagenes/registro.jpg")));
		lblfondo.setBounds(0, 0, 722, 496);
		frame.getContentPane().add(lblfondo);
		
		frame.setVisible(true);
	}
}
