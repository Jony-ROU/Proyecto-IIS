package vistas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Crear {

	private JFrame frame;
	private JFrame inicio;
	private JTextField textGenero;
	private JTextField textPublicacion;
	private JTextField textPrecio;
	private JTextField textEditorial;
	private JTextField textDescripcion;
	private JTextField textAutor;
	private JTextField textTitulo;
	private JTextField textISBN;

	/**
	 * Launch the application.
	 */
	
/**	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Crear window = new Crear();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}**/
	

	/**
	 * Create the application.
	 */
	public Crear(JFrame ini) {
		initialize(ini);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(JFrame ini) {
		frame = new JFrame();
		frame.setBounds(100, 100, 736, 533);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblGenero = new JLabel("Genero");
		lblGenero.setForeground(Color.LIGHT_GRAY);
		lblGenero.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblGenero.setBounds(75, 212, 82, 16);
		frame.getContentPane().add(lblGenero);
		
		textGenero = new JTextField();
		textGenero.setBounds(167, 209, 142, 19);
		frame.getContentPane().add(textGenero);
		textGenero.setColumns(10);
		
		JLabel lblPublicacion = new JLabel("A\u00F1o de publicaci\u00F3n");
		lblPublicacion.setForeground(Color.LIGHT_GRAY);
		lblPublicacion.setHorizontalAlignment(SwingConstants.CENTER);
		lblPublicacion.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPublicacion.setBounds(10, 268, 190, 25);
		frame.getContentPane().add(lblPublicacion);
		
		textPublicacion = new JTextField();
		textPublicacion.setBounds(213, 272, 96, 26);
		frame.getContentPane().add(textPublicacion);
		textPublicacion.setColumns(10);
		
		JLabel lblPrecio = new JLabel("Precio");
		lblPrecio.setForeground(Color.LIGHT_GRAY);
		lblPrecio.setHorizontalAlignment(SwingConstants.CENTER);
		lblPrecio.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPrecio.setBounds(404, 89, 82, 25);
		frame.getContentPane().add(lblPrecio);
		
		textPrecio = new JTextField();
		textPrecio.setBounds(507, 96, 125, 19);
		frame.getContentPane().add(textPrecio);
		textPrecio.setColumns(10);
		
		JLabel lblEditorial = new JLabel("Editorial");
		lblEditorial.setForeground(Color.GRAY);
		lblEditorial.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblEditorial.setBounds(405, 144, 81, 25);
		frame.getContentPane().add(lblEditorial);
		
		textEditorial = new JTextField();
		textEditorial.setBounds(507, 151, 125, 19);
		frame.getContentPane().add(textEditorial);
		textEditorial.setColumns(10);
		
		JLabel lblDescripcion = new JLabel("Descripci\u00F3n");
		lblDescripcion.setForeground(Color.DARK_GRAY);
		lblDescripcion.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblDescripcion.setBounds(396, 268, 114, 19);
		frame.getContentPane().add(lblDescripcion);
		
		textDescripcion = new JTextField();
		textDescripcion.setBounds(507, 268, 125, 19);
		frame.getContentPane().add(textDescripcion);
		textDescripcion.setColumns(10);
		
		JLabel lblAutor = new JLabel("Autor");
		lblAutor.setForeground(Color.LIGHT_GRAY);
		lblAutor.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblAutor.setBounds(75, 154, 82, 16);
		frame.getContentPane().add(lblAutor);
		
		textAutor = new JTextField();
		textAutor.setBounds(167, 151, 142, 19);
		frame.getContentPane().add(textAutor);
		textAutor.setColumns(10);
		
		JLabel lblTitulo = new JLabel("T\u00EDtulo");
		lblTitulo.setForeground(Color.LIGHT_GRAY);
		lblTitulo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitulo.setBounds(75, 92, 82, 19);
		frame.getContentPane().add(lblTitulo);
		
		textTitulo = new JTextField();
		textTitulo.setBounds(167, 96, 142, 19);
		frame.getContentPane().add(textTitulo);
		textTitulo.setColumns(10);
		
		JLabel lblISBN = new JLabel("ISBN");
		lblISBN.setForeground(Color.GRAY);
		lblISBN.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblISBN.setBounds(405, 209, 54, 16);
		frame.getContentPane().add(lblISBN);
		
		textISBN = new JTextField();
		textISBN.setBounds(507, 209, 125, 19);
		frame.getContentPane().add(textISBN);
		textISBN.setColumns(10);
		
		JLabel lblTitulo1 = new JLabel("Crear Libro");
		lblTitulo1.setForeground(Color.WHITE);
		lblTitulo1.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblTitulo1.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitulo1.setBounds(282, 10, 150, 37);
		frame.getContentPane().add(lblTitulo1);
		
		JButton btnCrear = new JButton("Crear");
		btnCrear.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnCrear.setBounds(512, 396, 120, 37);
		frame.getContentPane().add(btnCrear);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				inicio.setVisible(true);
				frame.dispose();
			}
		});
		btnCancelar.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnCancelar.setBounds(53, 396, 120, 37);
		frame.getContentPane().add(btnCancelar);
		
		JLabel lblFondo = new JLabel("");
		lblFondo.setIcon(new ImageIcon(Crear.class.getResource("/imagenes/LibroAbierto.jpg")));
		lblFondo.setBounds(0, 0, 722, 496);
		frame.getContentPane().add(lblFondo);
		
		
		frame.setVisible(true);
		inicio = ini;
	}
}
