package vistas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Inicio {

	private JFrame frame;
	
	/**
	 * Launch the application.
	 */
	
/**	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Inicio window = new Inicio();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}**/
	

	/**
	 * Create the application.
	 */
	public Inicio() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 736, 533);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		frame.setVisible(true);
		JButton btnCrearLibro = new JButton("Crear Libro");
		btnCrearLibro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				new Crear(frame);
			}
		});
		btnCrearLibro.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnCrearLibro.setBounds(8, 6, 174, 40);
		frame.getContentPane().add(btnCrearLibro);
		
		JButton btnInicio = new JButton("Salir");
		btnInicio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				new Login();
			}
		});
		btnInicio.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnInicio.setBounds(571, 10, 143, 40);
		frame.getContentPane().add(btnInicio);
	}

}
