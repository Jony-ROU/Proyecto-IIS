package vistas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.SwingConstants;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Color;

public class verDetalles {

	private JFrame frame;
	private JFrame inicio;
	private JTextField textTitulo;
	private JTextField textAutor;
	private JTextField textGenero;
	private JTextField textPrecio;
	private JTextField textPublicacion;
	private JTextField textISBN;
	private JTextField textEditorial;
	private JTextField textLista;
	private String[] libro;
	private List<String> listas = new ArrayList<>();


	/**
	 * Create the application.
	 */
	public verDetalles(JFrame inicio,String[] libro) {
		initialize(inicio,libro);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(JFrame inicio,String[] libro) {
		frame = new JFrame();
		frame.setBounds(100, 100, 753, 576);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		this.libro=libro;
		
		JLabel lblImagen = new JLabel("");
		lblImagen.setBounds(260, 25, 206, 204);
		frame.getContentPane().add(lblImagen);
		
		
		
		JLabel lblTitulo = new JLabel("T\u00EDtulo");
		lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitulo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTitulo.setBounds(41, 275, 80, 26);
		frame.getContentPane().add(lblTitulo);
		
		textTitulo = new JTextField();
		textTitulo.setEditable(false);
		textTitulo.setBounds(119, 276, 88, 26);
		frame.getContentPane().add(textTitulo);
		textTitulo.setColumns(10);
		textTitulo.setText(libro[1]);
		
		JLabel lblAutor = new JLabel("Autor");
		lblAutor.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblAutor.setBounds(282, 275, 72, 24);
		frame.getContentPane().add(lblAutor);
		
		textAutor = new JTextField();
		textAutor.setEditable(false);
		textAutor.setBounds(362, 275, 88, 27);
		frame.getContentPane().add(textAutor);
		textAutor.setColumns(10);
		textAutor.setText(libro[2]);
		
		JLabel lblGenero = new JLabel("G\u00E9nero");
		lblGenero.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblGenero.setBounds(518, 275, 80, 24);
		frame.getContentPane().add(lblGenero);
		
		textGenero = new JTextField();
		textGenero.setEditable(false);
		textGenero.setBounds(606, 275, 86, 27);
		frame.getContentPane().add(textGenero);
		textGenero.setColumns(10);
		textGenero.setText(libro[5]);
		
		JLabel lblPrecio = new JLabel("Precio");
		lblPrecio.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPrecio.setBounds(41, 350, 70, 23);
		frame.getContentPane().add(lblPrecio);
		
		textPrecio = new JTextField();
		textPrecio.setEditable(false);
		textPrecio.setBounds(119, 350, 88, 26);
		frame.getContentPane().add(textPrecio);
		textPrecio.setColumns(10);
		textPrecio.setText(libro[6]);
		
		JLabel lblDescripcion = new JLabel("Descripci\u00F3n");
		lblDescripcion.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblDescripcion.setBounds(295, 384, 122, 26);
		frame.getContentPane().add(lblDescripcion);
		
		JLabel lblPublicacion = new JLabel("A\u00F1o de publicaci\u00F3n");
		lblPublicacion.setHorizontalAlignment(SwingConstants.CENTER);
		lblPublicacion.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPublicacion.setBounds(410, 347, 188, 26);
		frame.getContentPane().add(lblPublicacion);
		
		
		textPublicacion = new JTextField();
		textPublicacion.setEditable(false);
		textPublicacion.setBounds(606, 350, 86, 26);
		frame.getContentPane().add(textPublicacion);
		textPublicacion.setColumns(10);
		textPublicacion.setText(libro[4]);
		
		JLabel lblISBN = new JLabel("ISBN");
		lblISBN.setHorizontalAlignment(SwingConstants.CENTER);
		lblISBN.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblISBN.setBounds(41, 213, 70, 16);
		frame.getContentPane().add(lblISBN);
		
		textISBN = new JTextField();
		textISBN.setEditable(false);
		textISBN.setBounds(119, 202, 86, 27);
		frame.getContentPane().add(textISBN);
		textISBN.setColumns(10);
		textISBN.setText(libro[0]);
		
		JLabel lblEditorial = new JLabel("Editorial");
		lblEditorial.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblEditorial.setHorizontalAlignment(SwingConstants.CENTER);
		lblEditorial.setBounds(503, 213, 95, 16);
		frame.getContentPane().add(lblEditorial);
		
		textEditorial = new JTextField();
		textEditorial.setEditable(false);
		textEditorial.setBounds(606, 202, 86, 27);
		frame.getContentPane().add(textEditorial);
		textEditorial.setColumns(10);
		textEditorial.setText(libro[3]);
		
		JTextArea textArea = new JTextArea();
		textArea.setEditable(false);
		textArea.setBounds(41, 420, 651, 92);
		frame.getContentPane().add(textArea);
		textArea.setText(libro[8]);
		
		JButton btnVolver = new JButton("Volver");
		btnVolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				inicio.setVisible(true);
				frame.dispose();
			}
		});
		btnVolver.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnVolver.setBounds(41, 34, 109, 35);
		frame.getContentPane().add(btnVolver);
		
		
		JMenuBar menuBarListas = new JMenuBar();
		menuBarListas.setBounds(500, 25, 65, 35);
		frame.getContentPane().add(menuBarListas);
		
		JMenu mnNewMenu = new JMenu("Listas");
		menuBarListas.add(mnNewMenu);
		
	
		
		textLista = new JTextField();
		textLista.setHorizontalAlignment(SwingConstants.CENTER);
		textLista.setEditable(false);
		textLista.setBounds(554, 87, 109, 35);
		frame.getContentPane().add(textLista);
		textLista.setColumns(10);
		
		mostrarListas(mnNewMenu);
		
		visualizar(lblImagen,libro);
		
		JButton btnIncluir = new JButton("A\u00F1adir libro");
		btnIncluir.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnIncluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!textLista.getText().equals("")) {
					anadirLibroLista();
				}else {
					JOptionPane.showMessageDialog(frame, "Lista no seleccionada", "Error",
							JOptionPane.ERROR_MESSAGE);
				}
				
			}
		});
		btnIncluir.setBounds(583, 25, 148, 41);
		frame.getContentPane().add(btnIncluir);
		
		JLabel lblFondo = new JLabel("");
		lblFondo.setIcon(new ImageIcon(verDetalles.class.getResource("/imagenes/pexels-pixabay-415071.jpg")));
		lblFondo.setBackground(Color.WHITE);
		lblFondo.setBounds(0, 0, 739, 539);
		frame.getContentPane().add(lblFondo);
		frame.setVisible(true);
		this.inicio = inicio;
	}
	
	
	
	
	
	
	
	void mostrarListas(JMenu mnNewMenu) {
		 try {
	            FileReader fileReader = new FileReader("listas.txt");
	            BufferedReader bufferedReader = new BufferedReader(fileReader);
	            
	            String linea =bufferedReader.readLine();
	            
	            
	            while (linea != null) {
	            	listas.add(linea);
	            	String[] datos = linea.split(",");
	            	if(datos.length>2) {
	            		if(datos[2].equals(textISBN.getText())) {
	            			textLista.setText(datos[0].toString());
	            		}
	            	}
	            	JMenuItem item = new JMenuItem(datos[0].toString());
	        		mnNewMenu.add(item);
	        		item.addActionListener(new ActionListener() {
	                    public void actionPerformed(ActionEvent e) {
	                    	textLista.setText(datos[0].toString());
	                    }
	                });
	                
	                linea = bufferedReader.readLine();
	            }

	            bufferedReader.close();
	        } catch (IOException e2) {
	        	
	            e2.printStackTrace();
	            
	        }
	}
	
	
	
	
	
	void visualizar(JLabel label,String[] libro) {
		if(libro[1]!=null) {
			try {
				
	            // URL de la imagen
	            URL url = new URL(libro[7]);

	            // Cargar la imagen
	            Image image = ImageIO.read(url);

	            // Crear un ImageIcon a partir de la imagen
	            ImageIcon imageIcon = new ImageIcon(image);

	            // Ajustar la imagen al tama�o del JLabel
	            imageIcon = new ImageIcon(imageIcon.getImage().getScaledInstance(label.getWidth(), label.getHeight(), Image.SCALE_DEFAULT));

	            // A�adir el ImageIcon al JLabel
	            label.setIcon(imageIcon);

	        } catch (Exception e) {
	            e.printStackTrace();
	        }
		}
	}
	
	void anadirLibroLista() {
		
		int respuesta = JOptionPane.showConfirmDialog(null, "�Deseas INCLUIR este libro a la lista?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (respuesta == JOptionPane.YES_OPTION) {
        	
        	
        	try {


                FileWriter fileWriter = new FileWriter("listas.txt");
                BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
                String lista = textLista.getText();
                
                for (int i =0; i<listas.size(); i++) {
                	String[] datos = listas.get(i).split(",");
                	if(lista.equals(datos[0])) {
                		if(datos.length>2) {
                			bufferedWriter.write(listas.get(i));
                            bufferedWriter.newLine();
                            bufferedWriter.write(datos[0].toString()+","+datos[1].toString()+","+textISBN.getText());
                		}else {
                			bufferedWriter.write(listas.get(i)+","+textISBN.getText());
                            bufferedWriter.newLine();
                		}
                		
                	}else {
                		bufferedWriter.write(listas.get(i));
                        bufferedWriter.newLine();
                	}
    				
    			}

                bufferedWriter.close();
            } catch (IOException e2) {
            	
                e2.printStackTrace();
                
            }
        	

        	
        	JOptionPane.showMessageDialog(frame, "Libro incluido correctamente", "Correcto",
					JOptionPane.INFORMATION_MESSAGE);
        	
        	
        	
        	
        } 
        
	}
}
