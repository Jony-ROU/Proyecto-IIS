package vistas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.SwingConstants;

public class Inicio {

	private JFrame frame;
	private String[] libro1 = new String[9];
	private String[] libro2 = new String[9];
	private String[] libro3 = new String[9];
	private String[] libro4 = new String[9];
	JLabel lblLibro1 ;
	JLabel lblLibro2 ;
	JLabel lblLibro3 ;
	JLabel lblLibro4 ;
	JLabel lblTitulo1 ;
	JLabel lblTitulo2 ;
	JLabel lblTitulo3 ;
	JLabel lblTitulo4 ;
	
	/**
	 * Launch the application.
	 */
	

	

	/**
	 * Create the application.
	 */
	public Inicio() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 753, 576);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		frame.setVisible(true);
		
		cargarLibro();
		componentes();
		visualizar(lblLibro1,libro1,lblTitulo1);
		visualizar(lblLibro2,libro2,lblTitulo2);
		visualizar(lblLibro3,libro3,lblTitulo3);
		visualizar(lblLibro4,libro4,lblTitulo4);
		
		JButton btnCrearLista = new JButton("CrearLista");
		btnCrearLista.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new CrearLista(frame);
				frame.setVisible(false);
			}
		});
		btnCrearLista.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnCrearLista.setBounds(267, 372, 164, 40);
		frame.getContentPane().add(btnCrearLista);
		
		JLabel lblFondo = new JLabel("");
		lblFondo.setIcon(new ImageIcon(Inicio.class.getResource("/imagenes/Librer\u00EDa-a-medida-con-baldas-y-cubos-2.jpg")));
		lblFondo.setBounds(0, 6, 739, 533);
		frame.getContentPane().add(lblFondo);
		
		
	}
	
	void componentes() {
		JButton btnCrearLibro = new JButton("Crear Libro");
		btnCrearLibro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Crear();
				frame.dispose();
			}
		});
		btnCrearLibro.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnCrearLibro.setBounds(257, 10, 174, 40);
		frame.getContentPane().add(btnCrearLibro);
		
		JButton btnInicio = new JButton("Salir");
		btnInicio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				new Login();
			}
		});
		btnInicio.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnInicio.setBounds(616, 10, 115, 40);
		frame.getContentPane().add(btnInicio);
		
		lblLibro1 = new JLabel("");
		lblLibro1.setBounds(96, 45, 121, 151);
		frame.getContentPane().add(lblLibro1);
		
		lblLibro2 = new JLabel("");
		lblLibro2.setBounds(478, 45, 121, 151);
		frame.getContentPane().add(lblLibro2);
		
		JButton btnVer1 = new JButton("Visualizar");
		btnVer1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(libro1[0]!=null) {
					new verDetalles(frame,libro1);
					frame.setVisible(false);
				}else {
					JOptionPane.showMessageDialog(frame, "Libro no disponible para visualizar", "Advertencia",
							JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnVer1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnVer1.setBounds(37, 206, 122, 30);
		frame.getContentPane().add(btnVer1);
		
		JButton btnEliminar1 = new JButton("Eliminar");
		btnEliminar1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(libro1[0]!=null) {
					
					int respuesta = JOptionPane.showConfirmDialog(null, "�Deseas eliminar este libro?", "Confirmar", JOptionPane.YES_NO_OPTION);
			        if (respuesta == JOptionPane.YES_OPTION) {
			        	eliminarLibro(libro1);
			        	JOptionPane.showMessageDialog(frame, "Libro eliminado correctamente", "Correcto",
								JOptionPane.INFORMATION_MESSAGE);
			        	
			        	new Inicio();
			        	frame.dispose();
			        } 
					
					
				}else {
					JOptionPane.showMessageDialog(frame, "Libro no disponible", "Error",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnEliminar1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnEliminar1.setBounds(167, 206, 115, 30);
		frame.getContentPane().add(btnEliminar1);
		
		JButton btnVer2 = new JButton("Visualizar");
		btnVer2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnVer2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(libro2[0]!=null) {
					new verDetalles(frame,libro2);
					frame.setVisible(false);
				}else {
					JOptionPane.showMessageDialog(frame, "Libro no disponible para visualizar", "Advertencia",
							JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnVer2.setBounds(421, 206, 121, 30);
		frame.getContentPane().add(btnVer2);
		
		JButton btnEliminar2 = new JButton("Eliminar");
		btnEliminar2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(libro2[0]!=null) {
					
					int respuesta = JOptionPane.showConfirmDialog(null, "�Deseas eliminar este libro?", "Confirmar", JOptionPane.YES_NO_OPTION);
			        if (respuesta == JOptionPane.YES_OPTION) {
			        	eliminarLibro(libro2);
			        	JOptionPane.showMessageDialog(frame, "Libro eliminado correctamente", "Correcto",
								JOptionPane.INFORMATION_MESSAGE);
			        	
			        	new Inicio();
			        	frame.dispose();
			        } 
					
					
				}else {
					JOptionPane.showMessageDialog(frame, "Libro no disponible", "Error",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnEliminar2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnEliminar2.setBounds(551, 206, 115, 30);
		frame.getContentPane().add(btnEliminar2);
		
		lblLibro3 = new JLabel("");
		lblLibro3.setBounds(96, 283, 121, 151);
		frame.getContentPane().add(lblLibro3);
		
		JButton btnVer3 = new JButton("Visualizar");
		btnVer3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(libro3[0]!=null) {
					new verDetalles(frame,libro3);
					frame.setVisible(false);
				}else {
					JOptionPane.showMessageDialog(frame, "Libro no disponible para visualizar", "Advertencia",
							JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnVer3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnVer3.setBounds(37, 466, 122, 30);
		frame.getContentPane().add(btnVer3);
		
		JButton btnEliminar3 = new JButton("Eliminar");
		btnEliminar3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(libro3[0]!=null) {
					
					int respuesta = JOptionPane.showConfirmDialog(null, "�Deseas eliminar este libro?", "Confirmar", JOptionPane.YES_NO_OPTION);
			        if (respuesta == JOptionPane.YES_OPTION) {
			        	eliminarLibro(libro3);
			        	JOptionPane.showMessageDialog(frame, "Libro eliminado correctamente", "Correcto",
								JOptionPane.INFORMATION_MESSAGE);
			        	
			        	new Inicio();
			        	frame.dispose();
			        } 
					
					
				}else {
					JOptionPane.showMessageDialog(frame, "Libro no disponible", "Error",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnEliminar3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnEliminar3.setBounds(167, 466, 115, 30);
		frame.getContentPane().add(btnEliminar3);
		
		lblLibro4 = new JLabel("");
		lblLibro4.setBounds(478, 283, 121, 151);
		frame.getContentPane().add(lblLibro4);
		
		JButton btnVer4 = new JButton("Visualizar");
		btnVer4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(libro4[0]!=null) {
					new verDetalles(frame,libro4);
					frame.setVisible(false);
				}else {
					JOptionPane.showMessageDialog(frame, "Libro no disponible para visualizar", "Advertencia",
							JOptionPane.WARNING_MESSAGE);
				}
				
			}
		});
		btnVer4.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnVer4.setBounds(421, 466, 121, 30);
		frame.getContentPane().add(btnVer4);
		
		JButton btnEliminar4 = new JButton("Eliminar");
		btnEliminar4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(libro4[0]!=null) {
					
					int respuesta = JOptionPane.showConfirmDialog(null, "�Deseas eliminar este libro?", "Confirmar", JOptionPane.YES_NO_OPTION);
			        if (respuesta == JOptionPane.YES_OPTION) {
			        	eliminarLibro(libro4);
			        	JOptionPane.showMessageDialog(frame, "Libro eliminado correctamente", "Correcto",
								JOptionPane.INFORMATION_MESSAGE);
			        	
			        	new Inicio();
			        	frame.dispose();
			        	
			        } 
					
					
				}else {
					JOptionPane.showMessageDialog(frame, "Libro no disponible", "Error",
							JOptionPane.ERROR_MESSAGE);
				}
				
			}
		});
		btnEliminar4.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnEliminar4.setBounds(551, 466, 115, 30);
		frame.getContentPane().add(btnEliminar4);
		
		lblTitulo1 = new JLabel("");
		lblTitulo1.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitulo1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblTitulo1.setForeground(Color.WHITE);
		lblTitulo1.setBounds(112, 28, 92, 13);
		frame.getContentPane().add(lblTitulo1);
		
		lblTitulo2 = new JLabel("");
		lblTitulo2.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitulo2.setForeground(Color.WHITE);
		lblTitulo2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblTitulo2.setBounds(472, 28, 92, 13);
		frame.getContentPane().add(lblTitulo2);
		
		lblTitulo3 = new JLabel("");
		lblTitulo3.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitulo3.setForeground(Color.WHITE);
		lblTitulo3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblTitulo3.setBounds(112, 260, 92, 13);
		frame.getContentPane().add(lblTitulo3);
		
		lblTitulo4 = new JLabel("");
		lblTitulo4.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitulo4.setForeground(Color.WHITE);
		lblTitulo4.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblTitulo4.setBounds(478, 260, 86, 13);
		frame.getContentPane().add(lblTitulo4);
	}
	
	void visualizar(JLabel label,String[] libro,JLabel lblTitulo) {
		if(libro[1]!=null) {
			try {
				lblTitulo.setText(libro[1]);
	            // URL de la imagen
	            URL url = new URL(libro[7]);

	            // Cargar la imagen
	            Image image = ImageIO.read(url);

	            // Crear un ImageIcon a partir de la imagen
	            ImageIcon imageIcon = new ImageIcon(image);

	            // Ajustar la imagen al tama�o del JLabel
	            imageIcon = new ImageIcon(imageIcon.getImage().getScaledInstance(label.getWidth(), label.getHeight(), Image.SCALE_DEFAULT));

	            // A�adir el ImageIcon al JLabel
	            label.setIcon(imageIcon);

	        } catch (Exception e) {
	            e.printStackTrace();
	        }
		}
	}
	
	void cargarLibro() {
		try {
            FileReader fileReader = new FileReader("libro.txt");
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            int n =0;
            String linea =bufferedReader.readLine();
            
            while (linea != null && n!=4 ) {
            	if(n==0) {
            		libro1=linea.split(",");
            	}else if(n==1) {
            		libro2=linea.split(",");
            	}else if(n==2) {
            		libro3=linea.split(",");
            	}else if(n==3) {
            		libro4=linea.split(",");
            	}
            	
                n++;
                linea = bufferedReader.readLine();
            }

            bufferedReader.close();
        } catch (IOException e2) {
        	
            e2.printStackTrace();
            
        }
	}
	
	void eliminarLibro(String[] libros) {
 
        try {


            FileWriter fileWriter = new FileWriter("libro.txt");
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            String lib;
            
            if(libro1[0]!=null && !libros.equals(libro1)) {
            	
            	lib="";
            	for(int i =0;i<libro1.length;i++) {
            		if(i==0) {
            			lib=lib+libro1[i];
            		}else {
            			lib=lib+","+libro1[i];
            		}
            		
            	}
            	bufferedWriter.write(lib);
                bufferedWriter.newLine();
            }
            
            
            if(libro2[0]!=null &&!libros.equals(libro2)) {
            	
            	lib="";
            	for(int i =0;i<libro2.length;i++) {
            		if(i==0) {
            			lib=lib+libro2[i];
            		}else {
            			lib=lib+","+libro2[i];
            		}
            		
            	}
            	bufferedWriter.write(lib);
                bufferedWriter.newLine();
            }
            
            
            if(libro3[0]!=null &&!libros.equals(libro3)) {
            	
            	lib="";
            	for(int i =0;i<libro3.length;i++) {
            		if(i==0) {
            			lib=lib+libro3[i];
            		}else {
            			lib=lib+","+libro3[i];
            		}
            		
            	}
            	bufferedWriter.write(lib);
                bufferedWriter.newLine();
            }
            
            
            if(libro4[0]!=null &&!libros.equals(libro4)) {
            	
            	lib="";
            	for(int i =0;i<libro4.length;i++) {
            		if(i==0) {
            			lib=lib+libro4[i];
            		}else {
            			lib=lib+","+libro4[i];
            		}
            		
            	}
            	bufferedWriter.write(lib);
                bufferedWriter.newLine();
            }
            
            
            
            bufferedWriter.close();
        } catch (IOException e2) {
        	
            e2.printStackTrace();
            
        }
	}
}
