package vistas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class CrearLista {

	private JFrame frame;
	private JTextField textNombre;
	private JFrame inicio;
	

	/**
	 * Create the application.
	 */
	public CrearLista(JFrame inicio) {
		initialize(inicio);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(JFrame inicio) {
		frame = new JFrame();
		frame.setBounds(100, 100, 753, 576);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		this.inicio = inicio;
		JLabel lblTitulo = new JLabel("Nueva Lista");
		lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitulo.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblTitulo.setBounds(193, 32, 295, 37);
		frame.getContentPane().add(lblTitulo);
		
		textNombre = new JTextField();
		textNombre.setBounds(243, 193, 210, 19);
		frame.getContentPane().add(textNombre);
		textNombre.setColumns(10);
		
		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNombre.setBounds(298, 137, 86, 19);
		frame.getContentPane().add(lblNombre);
		
		JLabel lblDescripcion = new JLabel("Descripci\u00F3n");
		lblDescripcion.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblDescripcion.setBounds(298, 280, 176, 29);
		frame.getContentPane().add(lblDescripcion);
		
		JTextArea textAreaDescripcion = new JTextArea();
		frame.getContentPane().add(textAreaDescripcion);
		textAreaDescripcion.setBounds(27, 319, 676, 143);
		textAreaDescripcion.setLineWrap(true);
		textAreaDescripcion.setWrapStyleWord(true);
		
		JButton btnCrear = new JButton("Crear");
		btnCrear.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				if(!textNombre.getText().equals("")&&!textAreaDescripcion.getText().equals("")) {
					try {
						
			            FileWriter fileWriter = new FileWriter("listas.txt",true);
			            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
			            String lista = textNombre.getText()+","+textAreaDescripcion.getText();
			            bufferedWriter.write(lista);
			            bufferedWriter.newLine();

			            bufferedWriter.close();
			        } catch (IOException e2) {
			            e2.printStackTrace();
			            JOptionPane.showMessageDialog(frame, "Error inesperado", "Error",
								JOptionPane.ERROR_MESSAGE);
			        }
					JOptionPane.showMessageDialog(frame, "Lista creada correctamente", "Correcto",
							JOptionPane.INFORMATION_MESSAGE);
					new Inicio();
					frame.dispose();
				}else {
					JOptionPane.showMessageDialog(frame, "Debe poner un nombre", "Error",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnCrear.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnCrear.setBounds(556, 492, 119, 37);
		frame.getContentPane().add(btnCrear);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				inicio.setVisible(true);
				frame.dispose();
			}
		});
		btnCancelar.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnCancelar.setBounds(53, 492, 119, 37);
		frame.getContentPane().add(btnCancelar);
		
		JLabel lblFondo = new JLabel("New label");
		lblFondo.setIcon(new ImageIcon(CrearLista.class.getResource("/imagenes/pexels-pixabay-415071.jpg")));
		lblFondo.setBounds(0, 0, 739, 539);
		frame.getContentPane().add(lblFondo);
		
		frame.setVisible(true);
	}
}
