package vistas;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Color;

public class Login {

	private JFrame frame;
	private JTextField textFieldcorreo;
	private JPasswordField textPasswordcontrasena;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 736, 533);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		frame.setVisible(true);
		textFieldcorreo = new JTextField();
		textFieldcorreo.setBounds(208, 170, 270, 31);
		frame.getContentPane().add(textFieldcorreo);
		textFieldcorreo.setColumns(10);
		
		JLabel lblcorreo = new JLabel("Correo electrónico");
		lblcorreo.setForeground(Color.BLACK);
		lblcorreo.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 25));
		lblcorreo.setHorizontalAlignment(SwingConstants.CENTER);
		lblcorreo.setBounds(190, 121, 300, 39);
		frame.getContentPane().add(lblcorreo);
		
		textPasswordcontrasena = new JPasswordField();
		textPasswordcontrasena.setBounds(208, 321, 270, 31);
		frame.getContentPane().add(textPasswordcontrasena);
		textPasswordcontrasena.setColumns(10);
		
		JLabel lblcontrasena = new JLabel("Contraseña");
		lblcontrasena.setForeground(Color.BLACK);
		lblcontrasena.setHorizontalAlignment(SwingConstants.CENTER);
		lblcontrasena.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 25));
		lblcontrasena.setBounds(208, 273, 270, 38);
		frame.getContentPane().add(lblcontrasena);
		
		JLabel lbltitulo = new JLabel("Iniciar Sesión");
		lbltitulo.setForeground(Color.BLACK);
		lbltitulo.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 40));
		lbltitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lbltitulo.setBounds(161, 29, 364, 66);
		frame.getContentPane().add(lbltitulo);
		
		JButton btnNewButton = new JButton("Entrar");
		btnNewButton.setIcon(null);
		btnNewButton.setForeground(Color.DARK_GRAY);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String correo = textFieldcorreo.getText();
				char[] contra = textPasswordcontrasena.getPassword();
				boolean ok = false;
		        try {
		            FileReader fileReader = new FileReader("usuario.txt");
		            BufferedReader bufferedReader = new BufferedReader(fileReader);
		            
		            String linea =bufferedReader.readLine();
		            
		            while (linea != null && !ok ) {
		            	String[] datos = linea.split(",");
		            	if(correo.equals(datos[0]) && String.valueOf(contra).equals(datos[1])) {
		            		ok = true;
		            	}
		                
		                linea = bufferedReader.readLine();
		            }

		            bufferedReader.close();
		        } catch (IOException e2) {
		        	
		            e2.printStackTrace();
		            
		        }
		        if(ok) {
		        	frame.setVisible(false);
		        	String[] email = correo.split("@");
		        	if(email[1].equals("textheos.es")) {
		        		new Inicio();
		        	}else {
		        		new InicioUsuario();
		        	}
					
		        }else {
		        	JOptionPane.showMessageDialog(frame, "Error, usuario o contrasña no válidos", "Error",
							JOptionPane.ERROR_MESSAGE);
		        }
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton.setBounds(57, 413, 155, 47);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Registrarse");
		btnNewButton_1.setForeground(Color.DARK_GRAY);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				frame.setVisible(false);
				new Register(frame);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 21));
		btnNewButton_1.setBounds(506, 413, 155, 47);
		frame.getContentPane().add(btnNewButton_1);
		
		/*JLabel lblfondo = new JLabel("");
		lblfondo.setIcon(new ImageIcon(Login.class.getResource("/imagenes/bibliotecaLogin.jpg")));
		lblfondo.setBounds(0, 0, 722, 496);
		frame.getContentPane().add(lblfondo);*/
	}
}
