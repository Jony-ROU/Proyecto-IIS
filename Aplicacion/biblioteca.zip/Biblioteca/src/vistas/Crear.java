package vistas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JList;
import javax.swing.JSeparator;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JMenu;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JPopupMenu;

public class Crear {

	private JFrame frame;
	
	private JTextField textGenero;
	private JTextField textPublicacion;
	private JTextField textPrecio;
	private JTextField textEditorial;
	private JTextField textAutor;
	private JTextField textTitulo;
	private JTextField textISBN;
	private JTextField textImagen;

	/**
	 * Launch the application.
	 */
	

	

	/**
	 * Create the application.
	 */
	public Crear() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 736, 533);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblGenero = new JLabel("Genero");
		lblGenero.setForeground(Color.LIGHT_GRAY);
		lblGenero.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblGenero.setBounds(75, 212, 82, 25);
		frame.getContentPane().add(lblGenero);
		
		
		
		textGenero = new JTextField();
		textGenero.setBounds(263, 219, 81, 19);
		frame.getContentPane().add(textGenero);
		textGenero.setColumns(10);
		
		JLabel lblPublicacion = new JLabel("A\u00F1o de publicaci\u00F3n");
		lblPublicacion.setForeground(Color.LIGHT_GRAY);
		lblPublicacion.setHorizontalAlignment(SwingConstants.CENTER);
		lblPublicacion.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPublicacion.setBounds(10, 268, 190, 25);
		frame.getContentPane().add(lblPublicacion);
		
		textPublicacion = new JTextField();
		textPublicacion.setBounds(213, 272, 96, 26);
		frame.getContentPane().add(textPublicacion);
		textPublicacion.setColumns(10);
		
		JLabel lblPrecio = new JLabel("Precio");
		lblPrecio.setForeground(Color.LIGHT_GRAY);
		lblPrecio.setHorizontalAlignment(SwingConstants.CENTER);
		lblPrecio.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPrecio.setBounds(404, 89, 82, 25);
		frame.getContentPane().add(lblPrecio);
		
		textPrecio = new JTextField();
		textPrecio.setBounds(507, 96, 125, 19);
		frame.getContentPane().add(textPrecio);
		textPrecio.setColumns(10);
		
		JLabel lblEditorial = new JLabel("Editorial");
		lblEditorial.setForeground(Color.GRAY);
		lblEditorial.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblEditorial.setBounds(405, 144, 81, 25);
		frame.getContentPane().add(lblEditorial);
		
		textEditorial = new JTextField();
		textEditorial.setBounds(507, 151, 125, 19);
		frame.getContentPane().add(textEditorial);
		textEditorial.setColumns(10);
		
		JLabel lblDescripcion = new JLabel("Descripci\u00F3n");
		lblDescripcion.setForeground(Color.DARK_GRAY);
		lblDescripcion.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblDescripcion.setBounds(404, 290, 118, 19);
		frame.getContentPane().add(lblDescripcion);
		
		JLabel lblAutor = new JLabel("Autor");
		lblAutor.setForeground(Color.LIGHT_GRAY);
		lblAutor.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblAutor.setBounds(75, 154, 82, 16);
		frame.getContentPane().add(lblAutor);
		
		textAutor = new JTextField();
		textAutor.setBounds(167, 151, 142, 19);
		frame.getContentPane().add(textAutor);
		textAutor.setColumns(10);
		
		JLabel lblTitulo = new JLabel("T\u00EDtulo");
		lblTitulo.setForeground(Color.LIGHT_GRAY);
		lblTitulo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitulo.setBounds(75, 92, 82, 19);
		frame.getContentPane().add(lblTitulo);
		
		textTitulo = new JTextField();
		textTitulo.setBounds(167, 96, 142, 19);
		frame.getContentPane().add(textTitulo);
		textTitulo.setColumns(10);
		
		JLabel lblISBN = new JLabel("ISBN");
		lblISBN.setForeground(Color.GRAY);
		lblISBN.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblISBN.setBounds(405, 209, 54, 16);
		frame.getContentPane().add(lblISBN);
		
		textISBN = new JTextField();
		textISBN.setBounds(507, 209, 125, 19);
		frame.getContentPane().add(textISBN);
		textISBN.setColumns(10);
		
		JLabel lblTitulo1 = new JLabel("Crear Libro");
		lblTitulo1.setForeground(Color.WHITE);
		lblTitulo1.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblTitulo1.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitulo1.setBounds(282, 10, 150, 37);
		frame.getContentPane().add(lblTitulo1);
		
		
		JTextArea textAreaDescripcion = new JTextArea();
		frame.getContentPane().add(textAreaDescripcion);
		textAreaDescripcion.setBounds(404, 319, 299, 143);
		textAreaDescripcion.setLineWrap(true);
		textAreaDescripcion.setWrapStyleWord(true);
		
		
		JMenuBar menuBarPublicacion = new JMenuBar();
		menuBarPublicacion.setBounds(165, 219, 81, 19);
		frame.getContentPane().add(menuBarPublicacion);
		
		JMenu mnNewMenu = new JMenu("G�neros");
		menuBarPublicacion.add(mnNewMenu);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Ficci�n");
		mnNewMenu.add(mntmNewMenuItem);
		mntmNewMenuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                textGenero.setText("Ficci�n");
            }
        });
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("No Ficci�n");
		mnNewMenu.add(mntmNewMenuItem_1);
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                textGenero.setText("No Ficci�n");
            }
        });
		
		JMenuItem mntmNewMenuItem_2 = new JMenuItem("Literatura Infantil y Juvenil");
		mnNewMenu.add(mntmNewMenuItem_2);
		mntmNewMenuItem_2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                textGenero.setText("Literatura Infantil y Juvenil");
            }
        });
		
		JMenuItem mntmNewMenuItem_3 = new JMenuItem("Poes�a");
		mnNewMenu.add(mntmNewMenuItem_3);
		mntmNewMenuItem_3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                textGenero.setText("Poes�a");
            }
        });
		
		JMenuItem mntmNewMenuItem_4 = new JMenuItem("Arte");
		mnNewMenu.add(mntmNewMenuItem_4);
		mntmNewMenuItem_4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                textGenero.setText("Arte");
            }
        });
		
		JMenuItem mntmNewMenuItem_5 = new JMenuItem("C�mic y novela gr�fical");
		mnNewMenu.add(mntmNewMenuItem_5);
		mntmNewMenuItem_5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                textGenero.setText("C�mic y novela gr�fical");
            }
        });
		
		JMenuItem mntmNewMenuItem_6 = new JMenuItem("Edici�n acad�mica y libros de texto");
		mnNewMenu.add(mntmNewMenuItem_6);
		mntmNewMenuItem_6.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                textGenero.setText("Edici�n acad�mica y libros de texto");
            }
        });
		
		JMenuItem mntmNewMenuItem_7 = new JMenuItem("Cl�sicos");
		mnNewMenu.add(mntmNewMenuItem_7);
		mntmNewMenuItem_7.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                textGenero.setText("Cl�sicos");
            }
        });
		
		JMenuItem mntmNewMenuItem_8 = new JMenuItem("Romance");
		mnNewMenu.add(mntmNewMenuItem_8);
		mntmNewMenuItem_8.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                textGenero.setText("Romance");
            }
        });
		
		JMenuItem mntmNewMenuItem_9 = new JMenuItem("Aventura");
		mnNewMenu.add(mntmNewMenuItem_9);
		mntmNewMenuItem_9.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                textGenero.setText("Aventura");
            }
        });
		
		JMenuItem mntmNewMenuItem_10 = new JMenuItem("Terror");
		mnNewMenu.add(mntmNewMenuItem_10);
		mntmNewMenuItem_10.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                textGenero.setText("Terror");
            }
        });
		
		JLabel lblImagen = new JLabel("Imagen");
		lblImagen.setHorizontalAlignment(SwingConstants.CENTER);
		lblImagen.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblImagen.setForeground(Color.WHITE);
		lblImagen.setBounds(75, 319, 98, 29);
		frame.getContentPane().add(lblImagen);
		
		textImagen = new JTextField();
		textImagen.setBounds(213, 322, 131, 19);
		frame.getContentPane().add(textImagen);
		textImagen.setColumns(10);
		
		
		JButton btnCrear = new JButton("Crear");
		btnCrear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String titulo = textTitulo.getText();
					String ISBN = textISBN.getText();
					String ano_public = textPublicacion.getText();
					String descripcion = textAreaDescripcion.getText();
					String genero = textGenero.getText();
					String autor = textAutor.getText();
					String precio = textPrecio.getText();
					String editorial = textEditorial.getText();
					String imagen = textImagen.getText();
		            FileWriter fileWriter = new FileWriter("libro.txt",true);
		            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
		            String libro = ISBN+","+titulo+","+autor+","+editorial+","+ano_public+","+genero+","+precio+","+imagen+","+descripcion;
		            bufferedWriter.write(libro);
		            bufferedWriter.newLine();

		            bufferedWriter.close();
		        } catch (IOException e2) {
		            e2.printStackTrace();
		            JOptionPane.showMessageDialog(frame, "Error inesperado", "Error",
							JOptionPane.ERROR_MESSAGE);
		        }
				JOptionPane.showMessageDialog(frame, "Creado correctamente", "Correcto",
						JOptionPane.INFORMATION_MESSAGE);
				new Inicio();
				frame.dispose();
			}
		});
		btnCrear.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnCrear.setBounds(248, 396, 120, 37);
		frame.getContentPane().add(btnCrear);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Inicio();
				frame.dispose();
			}
		});
		btnCancelar.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnCancelar.setBounds(53, 396, 120, 37);
		frame.getContentPane().add(btnCancelar);
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(402, 319, 301, 143);
        frame.getContentPane().add(scrollPane);
        
        JLabel lbleuro = new JLabel("\u20AC");
        lbleuro.setFont(new Font("Tahoma", Font.PLAIN, 25));
        lbleuro.setForeground(Color.LIGHT_GRAY);
        lbleuro.setBounds(643, 96, 32, 25);
        frame.getContentPane().add(lbleuro);
        
        
        
        JLabel lblFondo = new JLabel("");
        lblFondo.setIcon(new ImageIcon(Crear.class.getResource("/imagenes/LibroAbierto.jpg")));
        lblFondo.setBounds(0, 0, 722, 496);
        frame.getContentPane().add(lblFondo);
		
		
		
		frame.setVisible(true);
		
	}
}
