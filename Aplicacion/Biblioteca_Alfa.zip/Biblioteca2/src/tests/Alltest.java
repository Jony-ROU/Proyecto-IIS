package tests;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import javax.swing.JFrame;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import vistas.Crear;
import vistas.CrearLista;
import vistas.Inicio;
import vistas.InicioUsuario;
import vistas.Login;
import vistas.Register;
import vistas.verDetalles;

class Alltest {

	@Test
    public void testCrearLibro() {
        Crear crear = new Crear();
        assertTrue(crear.crearLibro("imagen.jpg", "descripcion", "genero", "2024", "20", "editorial", "autor", "titulo", "ISBN"));
        assertFalse(crear.crearLibro("", "descripcion", "genero", "2024", "20", "editorial", "autor", "titulo", "ISBN"));
        assertFalse(crear.crearLibro("imagen.jpg", "", "genero", "2024", "20", "editorial", "autor", "titulo", "ISBN"));
        assertFalse(crear.crearLibro("imagen.jpg", "descripcion", "", "2024", "20", "editorial", "autor", "titulo", "ISBN"));
        assertFalse(crear.crearLibro("imagen.jpg", "descripcion", "genero", "", "20", "editorial", "autor", "titulo", "ISBN"));
        assertFalse(crear.crearLibro("imagen.jpg", "descripcion", "genero", "2024", "", "editorial", "autor", "titulo", "ISBN"));
        assertFalse(crear.crearLibro("imagen.jpg", "descripcion", "genero", "2024", "20", "", "autor", "titulo", "ISBN"));
        assertFalse(crear.crearLibro("imagen.jpg", "descripcion", "genero", "2024", "20", "editorial", "", "titulo", "ISBN"));
        assertFalse(crear.crearLibro("imagen.jpg", "descripcion", "genero", "2024", "20", "editorial", "autor", "", "ISBN"));
        assertFalse(crear.crearLibro("imagen.jpg", "descripcion", "genero", "2024", "20", "editorial", "autor", "titulo", ""));
    }

    @Test
    public void testInitializeCrearLibro() {
        Crear crear = new Crear();
        assertNotNull(crear.frame);
        assertNotNull(crear.textGenero);
        assertNotNull(crear.textPublicacion);
        assertNotNull(crear.textPrecio);
        assertNotNull(crear.textEditorial);
        assertNotNull(crear.textAutor);
        assertNotNull(crear.textTitulo);
        assertNotNull(crear.textISBN);
        assertNotNull(crear.textImagen);
    }

    @Test
    public void testFrameVisibilityCrearLibro() {
        Crear crear = new Crear();
        assertTrue(crear.frame.isVisible());
        crear.frame.setVisible(false);
        assertFalse(crear.frame.isVisible());
    }
    
    
    
    @Test
    public void testComprobarElementos() {
        CrearLista crearLista = new CrearLista(new JFrame());
        assertTrue(crearLista.comprobarElementos("nombre", "descripcion"));
        assertFalse(crearLista.comprobarElementos("", "descripcion"));
        assertFalse(crearLista.comprobarElementos("nombre", ""));
    }

    @Test
    public void testInitializeCrearLista() {
        CrearLista crearLista = new CrearLista(new JFrame());
        assertNotNull(crearLista.frame);
        assertNotNull(crearLista.textNombre);
    }

    @Test
    public void testFrameVisibilityCrearLista() {
        CrearLista crearLista = new CrearLista(new JFrame());
        assertTrue(crearLista.frame.isVisible());
        crearLista.frame.setVisible(false);
        assertFalse(crearLista.frame.isVisible());
    }

    
    @Test
    public void testExisteUsuarioLogin() {
        Login login = new Login();
        String pwd ="0000";
        char[] password = pwd.toCharArray();
        assertTrue(login.existeUsuario("admin@textheos.es", password));
        assertFalse(login.existeUsuario("usuario_inexistente@textheos.es", password));
    }

    @Test
    public void testInitializeLogin() {
        Login login = new Login();
        assertNotNull(login.frame);
        assertNotNull(login.textFieldcorreo);
        assertNotNull(login.textPasswordcontrasena);
    }

    @Test
    public void testCorreoFieldLogin() {
        Login login = new Login();
        assertEquals("", login.textFieldcorreo.getText());
        login.textFieldcorreo.setText("usuario@textheos.es");
        assertEquals("usuario@textheos.es", login.textFieldcorreo.getText());
    }

    @Test
    public void testPasswordFieldLogin() {
        Login login = new Login();
        String pwd ="";
        char[] password = pwd.toCharArray();
        assertArrayEquals(password, login.textPasswordcontrasena.getPassword());
        login.textPasswordcontrasena.setText(pwd);
        assertArrayEquals(password, login.textPasswordcontrasena.getPassword());
    }

    @Test
    public void testFrameVisibilityLogin() {
        Login login = new Login();
        assertTrue(login.frame.isVisible());
        login.frame.setVisible(false);
        assertFalse(login.frame.isVisible());
    }
    
    @Test
    public void testComprobarVacioRegister() {
        Register register = new Register(new JFrame());
        assertTrue(register.comprobarVacio("contrase�a".toCharArray(), "contrase�a".toCharArray(), "usuario@textheos.es"));
        assertFalse(register.comprobarVacio("".toCharArray(), "contrase�a".toCharArray(), "usuario@textheos.es"));
        assertFalse(register.comprobarVacio("contrase�a".toCharArray(), "".toCharArray(), "usuario@textheos.es"));
        assertFalse(register.comprobarVacio("contrase�a".toCharArray(), "contrase�a".toCharArray(), ""));
    }

    @Test
    public void testContrasenaIgualesRegister() {
        Register register = new Register(new JFrame());
        assertTrue(register.contrasenaIguales("contrase�a".toCharArray(), "contrase�a".toCharArray()));
        assertFalse(register.contrasenaIguales("contrase�a".toCharArray(), "contrasena".toCharArray()));
    }

    @Test
    public void testInitializeRegister() {
        Register register = new Register(new JFrame());
        assertNotNull(register.frame);
        assertNotNull(register.textCorreo);
        assertNotNull(register.paswcontrasena);
        assertNotNull(register.paswrpContrasena);
    }

    @Test
    public void testCorreoFieldRegister() {
        Register register = new Register(new JFrame());
        assertEquals("", register.textCorreo.getText());
        register.textCorreo.setText("usuario@textheos.es");
        assertEquals("usuario@textheos.es", register.textCorreo.getText());
    }

    @Test
    public void testPasswordFieldRegister() {
        Register register = new Register(new JFrame());
        String pwd ="";
        char[] password = pwd.toCharArray();
        assertArrayEquals(password, register.paswcontrasena.getPassword());
        register.paswcontrasena.setText(pwd);
        assertArrayEquals(password, register.paswcontrasena.getPassword());
    }

    @Test
    public void testRpPasswordFieldRegister() {
        Register register = new Register(new JFrame());
        String pwd ="";
        char[] password = pwd.toCharArray();
        assertArrayEquals(password, register.paswrpContrasena.getPassword());
        register.paswrpContrasena.setText(pwd);
        assertArrayEquals(password, register.paswrpContrasena.getPassword());
    }

    @Test
    public void testFrameVisibilityRegister() {
        Register register = new Register(new JFrame());
        assertTrue(register.frame.isVisible());
        register.frame.setVisible(false);
        assertFalse(register.frame.isVisible());
    }
    
    
    @Test
    public void testCrearListaAndCrearIntegration() {
        // Crear un mock de JFrame
        JFrame mockedFrame = Mockito.mock(JFrame.class);

        // Crear instancias de las clases a probar
        Crear crear = new Crear();
        CrearLista crearLista = new CrearLista(mockedFrame);

        // Establecer algunos valores
        crearLista.textNombre.setText("nombre");
        crearLista.textAreaDescripcion.setText("descripcion");
        crear.textTitulo.setText("titulo");
        crear.textISBN.setText("ISBN");
        crear.textPublicacion.setText("2024");
        crear.textAreaDescripcion.setText("descripcion");
        crear.textGenero.setText("genero");
        crear.textAutor.setText("autor");
        crear.textPrecio.setText("20");
        crear.textEditorial.setText("editorial");
        crear.textImagen.setText("imagen.jpg");

        // Realizar las pruebas de integración
        assertTrue(crearLista.comprobarElementos(crearLista.textNombre.getText(), crearLista.textAreaDescripcion.getText()));
        assertTrue(crear.crearLibro(crear.textImagen.getText(), crear.textAreaDescripcion.getText(), crear.textGenero.getText(), crear.textPublicacion.getText(), crear.textPrecio.getText(), crear.textEditorial.getText(), crear.textAutor.getText(), crear.textTitulo.getText(), crear.textISBN.getText()));
    }
	
	@Test
    public void testInicioUsuarioIntegration() {
        // Crear un mock de JFrame para pasar a las clases que lo requieran
        JFrame mockedFrame = Mockito.mock(JFrame.class);

        // Crear instancias de las clases a probar
        InicioUsuario inicioUsuario = new InicioUsuario();
        CrearLista crearLista = new CrearLista(mockedFrame);

        // Simular la carga de libros
        inicioUsuario.cargarLibro();

        // Verificar que los libros se cargan correctamente
        assertNotNull(inicioUsuario.libro1);
        assertNotNull(inicioUsuario.libro2);
        assertNotNull(inicioUsuario.libro3);
        assertNotNull(inicioUsuario.libro4);

        // Verificar que los JLabels se actualizan correctamente
        inicioUsuario.visualizar(inicioUsuario.lblLibro1, inicioUsuario.libro1);
        inicioUsuario.visualizar(inicioUsuario.lblLibro2, inicioUsuario.libro2);
        inicioUsuario.visualizar(inicioUsuario.lblLibro3, inicioUsuario.libro3);
        inicioUsuario.visualizar(inicioUsuario.lblLibro4, inicioUsuario.libro4);

        // Verificar que los JLabels no est�n vac�os despu�s de visualizar
        assertNotEquals("", inicioUsuario.lblLibro1.getIcon());
        assertNotEquals("", inicioUsuario.lblLibro2.getIcon());
        assertNotEquals("", inicioUsuario.lblLibro3.getIcon());
        assertNotEquals("", inicioUsuario.lblLibro4.getIcon());

        // Verificar la interacci�n entre InicioUsuario y CrearLista
        inicioUsuario.frame.setVisible(false); // Simular cierre de ventana
        crearLista.frame.setVisible(true); // Simular apertura de ventana de CrearLista

        // Verificar que la ventana de CrearLista es visible
        assertTrue(crearLista.frame.isVisible());
    }	
	
	@Test
    public void testInicioIntegration() {
        // Crear un mock de JFrame para pasar a las clases que lo requieran
        JFrame mockedFrame = Mockito.mock(JFrame.class);

        // Crear instancias de las clases a probar
        Inicio inicio = new Inicio();
        CrearLista crearLista = new CrearLista(mockedFrame);

        // Simular la carga de libros
        inicio.cargarLibro();

        // Verificar que los libros se cargan correctamente
        assertNotNull(inicio.libro1);
        assertNotNull(inicio.libro2);
        assertNotNull(inicio.libro3);
        assertNotNull(inicio.libro4);

        // Verificar que los JLabels se actualizan correctamente
        inicio.visualizar(inicio.lblLibro1, inicio.libro1, inicio.lblTitulo1);
        inicio.visualizar(inicio.lblLibro2, inicio.libro2, inicio.lblTitulo2);
        inicio.visualizar(inicio.lblLibro3, inicio.libro3, inicio.lblTitulo3);
        inicio.visualizar(inicio.lblLibro4, inicio.libro4, inicio.lblTitulo4);

        // Verificar que los JLabels no est�n vac�os despu�s de visualizar
        assertNotEquals("", inicio.lblLibro1.getIcon());
        assertNotEquals("", inicio.lblLibro2.getIcon());
        assertNotEquals("", inicio.lblLibro3.getIcon());
        assertNotEquals("", inicio.lblLibro4.getIcon());

        // Verificar la interacci�n entre Inicio y CrearLista
        inicio.frame.setVisible(false); // Simular cierre de ventana
        crearLista.frame.setVisible(true); // Simular apertura de ventana de CrearLista

        // Verificar que la ventana de CrearLista es visible
        assertTrue(crearLista.frame.isVisible());
    }
	
	@Test
    public void testLoginIntegration() {
        // Crear un mock de JFrame para pasar a las clases que lo requieran
        JFrame mockedFrame = Mockito.mock(JFrame.class);

        // Crear instancias de las clases a probar
        Login login = new Login();
        Register register = new Register(mockedFrame);

        // Simular la acci�n de iniciar sesi�n
        login.textFieldcorreo.setText("admin@textheos.es");
        login.textPasswordcontrasena.setText("0000");

        // Simular la acci�n del bot�n de entrar
        login.btnNewButton.doClick();

        // Verificar que la ventana de Login se cierra y se abre la ventana de Inicio o InicioUsuario
        assertFalse(login.frame.isVisible());
        // Aqu� se verificar�a si la ventana de Inicio o InicioUsuario es visible, pero como no tenemos acceso a esas instancias, no podemos hacer esa afirmaci�n aqu�.

        // Verificar la interacci�n entre Login y Register
        login.btnNewButton_1.doClick(); // Simular clic en el bot�n de registrarse

        // Verificar que la ventana de Register es visible
        assertTrue(register.frame.isVisible());
    }
	
	
	
	@Test
    public void testVerDetallesIntegration() {
        // Crear un mock de JFrame para pasar a las clases que lo requieran
        JFrame mockedInicio = new JFrame();

        // Crear instancias de las clases a probar
        String[] libro = {"ISBN123", "Titulo", "Autor", "Editorial", "2024", "Genero", "20", "http://imagen.jpg", "Descripcion"};
        verDetalles detalles = new verDetalles(mockedInicio, libro);

        // Simular la acci�n de visualizar detalles
        detalles.textTitulo.setText(libro[1]);
        detalles.textAutor.setText(libro[2]);
        detalles.textGenero.setText(libro[5]);
        detalles.textPrecio.setText(libro[6]);
        detalles.textPublicacion.setText(libro[4]);
        detalles.textISBN.setText(libro[0]);
        detalles.textEditorial.setText(libro[3]);
        detalles.textLista.setText("Lista1");

        // Simular la acci�n del bot�n de volver
        detalles.btnVolver.doClick();
        // Verificar que la ventana de verDetalles se cierra y se abre la ventana de inicio
        assertFalse(detalles.frame.isVisible());
        assertTrue(mockedInicio.isVisible());
        

        // Verificar que los campos de texto se actualizan correctamente con la informaci�n del libro
        assertEquals("Titulo", detalles.textTitulo.getText());
        assertEquals("Autor", detalles.textAutor.getText());
        assertEquals("Genero", detalles.textGenero.getText());
        assertEquals("20", detalles.textPrecio.getText());
        assertEquals("2024", detalles.textPublicacion.getText());
        assertEquals("ISBN123", detalles.textISBN.getText());
        assertEquals("Editorial", detalles.textEditorial.getText());
        assertEquals("Descripcion", detalles.textArea.getText());

        // Verificar que la lista de libros se actualiza correctamente
        // Esto requerir�a leer el archivo 'listasLibros.txt' y verificar que el libro est� all�.
        // Sin embargo, como no podemos interactuar con el sistema de archivos durante las pruebas,
        // esta parte se omite en este ejemplo.
    }

}
