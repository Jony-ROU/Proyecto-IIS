module Biblioteca2 {
	exports tests;
	exports vistas;

	requires java.desktop;
	requires junit;
	requires org.junit.jupiter.api;
	requires org.mockito;
}