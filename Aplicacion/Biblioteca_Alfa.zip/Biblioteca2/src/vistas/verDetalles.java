package vistas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

import javax.swing.SwingConstants;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Color;

public class verDetalles {

	public JFrame frame;
	public JFrame inicio;
	public JTextField textTitulo;
	public JTextField textAutor;
	public JTextField textGenero;
	public JTextField textPrecio;
	public JTextField textPublicacion;
	public JTextField textISBN;
	public JTextField textEditorial;
	public JTextField textLista;
	public String[] libro;
	public List<String> listas = new ArrayList<>();
	public List<String> listaLibros = new ArrayList<>();
	public JButton btnVolver;
	public JTextArea textArea;

	/**
	 * Create the application.
	 */
	public verDetalles(JFrame inicio, String[] libro) {
		initialize(inicio, libro);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(JFrame inicio, String[] libro) {
		frame = new JFrame();
		frame.setBounds(100, 100, 753, 576);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		this.libro = libro;

		JLabel lblImagen = new JLabel("");
		lblImagen.setBounds(260, 25, 206, 204);
		frame.getContentPane().add(lblImagen);

		JLabel lblTitulo = new JLabel("T\u00EDtulo");
		lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitulo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTitulo.setBounds(41, 275, 80, 26);
		frame.getContentPane().add(lblTitulo);

		textTitulo = new JTextField();
		textTitulo.setEditable(false);
		textTitulo.setBounds(119, 276, 88, 26);
		frame.getContentPane().add(textTitulo);
		textTitulo.setColumns(10);
		textTitulo.setText(libro[1]);

		JLabel lblAutor = new JLabel("Autor");
		lblAutor.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblAutor.setBounds(282, 275, 72, 24);
		frame.getContentPane().add(lblAutor);

		textAutor = new JTextField();
		textAutor.setEditable(false);
		textAutor.setBounds(362, 275, 88, 27);
		frame.getContentPane().add(textAutor);
		textAutor.setColumns(10);
		textAutor.setText(libro[2]);

		JLabel lblGenero = new JLabel("G\u00E9nero");
		lblGenero.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblGenero.setBounds(518, 275, 80, 24);
		frame.getContentPane().add(lblGenero);

		textGenero = new JTextField();
		textGenero.setEditable(false);
		textGenero.setBounds(606, 275, 86, 27);
		frame.getContentPane().add(textGenero);
		textGenero.setColumns(10);
		textGenero.setText(libro[5]);

		JLabel lblPrecio = new JLabel("Precio");
		lblPrecio.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPrecio.setBounds(41, 350, 70, 23);
		frame.getContentPane().add(lblPrecio);

		textPrecio = new JTextField();
		textPrecio.setEditable(false);
		textPrecio.setBounds(119, 350, 88, 26);
		frame.getContentPane().add(textPrecio);
		textPrecio.setColumns(10);
		textPrecio.setText(libro[6]);

		JLabel lblDescripcion = new JLabel("Descripci\u00F3n");
		lblDescripcion.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblDescripcion.setBounds(295, 384, 122, 26);
		frame.getContentPane().add(lblDescripcion);

		JLabel lblPublicacion = new JLabel("A\u00F1o de publicaci\u00F3n");
		lblPublicacion.setHorizontalAlignment(SwingConstants.CENTER);
		lblPublicacion.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPublicacion.setBounds(410, 347, 188, 26);
		frame.getContentPane().add(lblPublicacion);

		textPublicacion = new JTextField();
		textPublicacion.setEditable(false);
		textPublicacion.setBounds(606, 350, 86, 26);
		frame.getContentPane().add(textPublicacion);
		textPublicacion.setColumns(10);
		textPublicacion.setText(libro[4]);

		JLabel lblISBN = new JLabel("ISBN");
		lblISBN.setHorizontalAlignment(SwingConstants.CENTER);
		lblISBN.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblISBN.setBounds(41, 213, 70, 16);
		frame.getContentPane().add(lblISBN);

		textISBN = new JTextField();
		textISBN.setEditable(false);
		textISBN.setBounds(119, 202, 86, 27);
		frame.getContentPane().add(textISBN);
		textISBN.setColumns(10);
		textISBN.setText(libro[0]);

		JLabel lblEditorial = new JLabel("Editorial");
		lblEditorial.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblEditorial.setHorizontalAlignment(SwingConstants.CENTER);
		lblEditorial.setBounds(503, 213, 95, 16);
		frame.getContentPane().add(lblEditorial);

		textEditorial = new JTextField();
		textEditorial.setEditable(false);
		textEditorial.setBounds(606, 202, 86, 27);
		frame.getContentPane().add(textEditorial);
		textEditorial.setColumns(10);
		textEditorial.setText(libro[3]);

		textArea = new JTextArea();
		textArea.setEditable(false);
		textArea.setBounds(41, 420, 651, 92);
		frame.getContentPane().add(textArea);
		textArea.setText(libro[8]);

		btnVolver = new JButton("Volver");
		btnVolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				inicio.setVisible(true);
				frame.dispose();
			}
		});
		btnVolver.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnVolver.setBounds(41, 34, 109, 35);
		frame.getContentPane().add(btnVolver);

		JMenuBar menuBarListas = new JMenuBar();
		menuBarListas.setBounds(500, 25, 65, 35);
		frame.getContentPane().add(menuBarListas);

		JMenu mnNewMenu = new JMenu("Listas");
		menuBarListas.add(mnNewMenu);

		textLista = new JTextField();
		textLista.setHorizontalAlignment(SwingConstants.CENTER);
		textLista.setEditable(false);
		textLista.setBounds(554, 87, 109, 35);
		frame.getContentPane().add(textLista);
		textLista.setColumns(10);

		mostrarListas(mnNewMenu);

		visualizar(lblImagen, libro);

		JButton btnIncluir = new JButton("A\u00F1adir libro");
		btnIncluir.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnIncluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (!textLista.getText().equals("")) {
					anadirLibroLista();
				} else {
					JOptionPane.showMessageDialog(frame, "Lista no seleccionada", "Error",
							JOptionPane.ERROR_MESSAGE);
				}

			}
		});
		btnIncluir.setBounds(583, 25, 148, 41);
		frame.getContentPane().add(btnIncluir);

		JLabel lblFondo = new JLabel("");
		lblFondo.setIcon(new ImageIcon(verDetalles.class.getResource("/imagenes/pexels-pixabay-415071.jpg")));
		lblFondo.setBackground(Color.WHITE);
		lblFondo.setBounds(0, 0, 739, 539);
		frame.getContentPane().add(lblFondo);
		frame.setVisible(true);
		this.inicio = inicio;
	}

	void mostrarListas(JMenu mnNewMenu) {
		try {
			FileReader fileReader = new FileReader("listas.txt");
			BufferedReader bufferedReader = new BufferedReader(fileReader);

			String linea = bufferedReader.readLine();

			while (linea != null) {
				listas.add(linea);
				String[] datos = linea.split(",");
				if (datos.length > 2) {
					if (datos[2].equals(textISBN.getText())) {
						textLista.setText(datos[0].toString());
					}
				}
				JMenuItem item = new JMenuItem(datos[0].toString());
				mnNewMenu.add(item);
				item.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						textLista.setText(datos[0].toString());
					}
				});

				linea = bufferedReader.readLine();
			}

			bufferedReader.close();

			FileReader fileReader2 = new FileReader("listasLibros.txt");
			BufferedReader bufferedReader2 = new BufferedReader(fileReader);

			String linea2 = bufferedReader2.readLine();

			while (linea != null) {
				listaLibros.add(linea);
				String[] datos = linea.split(",");
				if (datos.length > 2) {
					for (int i = 2; i < datos.length; i++) {
						if (datos[i].equals(textISBN.getText())) {
							textLista.setText(datos[0].toString());
						}
					}
				}

				linea = bufferedReader2.readLine();
			}

			bufferedReader2.close();

		} catch (IOException e2) {

			e2.printStackTrace();

		}
	}

	void visualizar(JLabel label, String[] libro) {
		if (libro[1] != null) {
			try {
	
				// URL de la imagen
				URL url = new URL(libro[7]);
	
				// Cargar la imagen
				Image image = ImageIO.read(url);
	
				// Crear un ImageIcon a partir de la imagen
				ImageIcon imageIcon = new ImageIcon(image);
	
				// Obtener las dimensiones de la imagen original
				int imageWidth = imageIcon.getIconWidth();
				int imageHeight = imageIcon.getIconHeight();
	
				// Obtener las dimensiones del JLabel
				int labelWidth = label.getWidth();
				int labelHeight = label.getHeight();
	
				// Calcular la relación de aspecto de la imagen
				double imageRatio = (double) imageWidth / imageHeight;
	
				// Calcular las nuevas dimensiones de la imagen
				int newWidth = labelWidth;
				int newHeight = (int) (newWidth / imageRatio);
	
				// Si la nueva altura es mayor que la altura del JLabel, ajustar la altura y recalcular la anchura
				if (newHeight > labelHeight) {
					newHeight = labelHeight;
					newWidth = (int) (newHeight * imageRatio);
				}
	
				// Escalar la imagen
				imageIcon = new ImageIcon(imageIcon.getImage().getScaledInstance(newWidth, newHeight, Image.SCALE_DEFAULT));
	
				// Añadir el ImageIcon al JLabel
				label.setIcon(imageIcon);
	
				// Ajustar la posición de la imagen
				label.setHorizontalAlignment(JLabel.CENTER);
				label.setVerticalAlignment(JLabel.TOP);
	
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	void anadirLibroLista() {
		int respuesta = JOptionPane.showConfirmDialog(null, "¿Deseas INCLUIR este libro a la lista?", "Confirmar",
				JOptionPane.YES_NO_OPTION);
		if (respuesta == JOptionPane.YES_OPTION) {
			try {
				String lista = textLista.getText();
				File file = new File("listasLibros.txt");
				if (!file.exists()) {
					file.createNewFile();
				}
				List<String> lineas = Files.readAllLines(file.toPath(), StandardCharsets.UTF_8);
	
				boolean found = false;
				for (int i = 0; i < lineas.size(); i++) {
					String[] datos = lineas.get(i).split(",");
					if (lista.equals(datos[0])) {
						for (int j = 1; j < datos.length; j++) {
							if (datos[j].equals(textISBN.getText())) {
								JOptionPane.showMessageDialog(frame, "El libro ya está en la lista", "Error",
										JOptionPane.ERROR_MESSAGE);
								return;
							}
						}
						lineas.set(i, lineas.get(i) + "," + textISBN.getText());
						found = true;
					}
				}
	
				if (!found) {
					lineas.add(lista + "," + textISBN.getText());
				}
	
				Files.write(file.toPath(), lineas, StandardCharsets.UTF_8);
			} catch (IOException e2) {
				e2.printStackTrace();
			}
	
			JOptionPane.showMessageDialog(frame, "Libro incluido correctamente", "Correcto",
					JOptionPane.INFORMATION_MESSAGE);
		}
	}
}
