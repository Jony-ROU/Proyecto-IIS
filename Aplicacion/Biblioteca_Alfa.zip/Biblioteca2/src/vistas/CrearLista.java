package vistas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class CrearLista {

	public JFrame frame;
	public JTextField textNombre;
	public JFrame inicio;
	public JTextArea textAreaDescripcion;

	/**
	 * Create the application.
	 */
	public CrearLista(JFrame inicio) {
		initialize(inicio);
	}

	private boolean listaExiste(String nombreLista) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("listas.txt"));
            String line;
            while ((line = reader.readLine()) != null) {
                String nombreExistente = line.split(",")[0];
                if (nombreLista.equals(nombreExistente)) {
                    return true;
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(JFrame inicio) {
		frame = new JFrame();
		frame.setBounds(100, 100, 753, 576);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		this.inicio = inicio;
		JLabel lblTitulo = new JLabel("Nueva Lista");
		lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitulo.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblTitulo.setBounds(222, 32, 295, 37);
		frame.getContentPane().add(lblTitulo);
		
		textNombre = new JTextField();
		textNombre.setBounds(265, 193, 210, 30);
		frame.getContentPane().add(textNombre);
		
		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNombre.setBounds(332, 137, 86,	 19);
		frame.getContentPane().add(lblNombre);
		
		JLabel lblDescripcion = new JLabel("Descripci\u00F3n");
		lblDescripcion.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblDescripcion.setBounds(318, 280, 176, 29);
		frame.getContentPane().add(lblDescripcion);
		
		textAreaDescripcion = new JTextArea();
		frame.getContentPane().add(textAreaDescripcion);
		textAreaDescripcion.setBounds(27, 319, 676, 143);
		textAreaDescripcion.setLineWrap(true);
		textAreaDescripcion.setWrapStyleWord(true);
		
		JButton btnCrear = new JButton("Crear");
        btnCrear.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nombreLista = textNombre.getText();
                String descripcionLista = textAreaDescripcion.getText();
                if (comprobarElementos(nombreLista, descripcionLista)) {
                    if (listaExiste(nombreLista)) {
                        JOptionPane.showMessageDialog(frame, "La lista ya existe", "Error",
                                JOptionPane.ERROR_MESSAGE);
                    } else {
                        try {
                            FileWriter fileWriter = new FileWriter("listas.txt", true);
                            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
                            String lista = nombreLista + "," + descripcionLista;
                            bufferedWriter.write(lista);
                            bufferedWriter.newLine(); // Agrega una nueva línea después de cada lista

                            bufferedWriter.close();
                        } catch (IOException e2) {
                            e2.printStackTrace();
                            JOptionPane.showMessageDialog(frame, "Error inesperado", "Error",
                                    JOptionPane.ERROR_MESSAGE);
                        }
                        JOptionPane.showMessageDialog(frame, "Lista creada correctamente", "Correcto",
                                JOptionPane.INFORMATION_MESSAGE);
                        inicio.setVisible(true);
                        frame.dispose();
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "Debe poner un nombre", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });
		btnCrear.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnCrear.setBounds(556, 492, 119, 37);
		frame.getContentPane().add(btnCrear);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				inicio.setVisible(true);
				frame.dispose();
			}
		});
		btnCancelar.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnCancelar.setBounds(53, 492, 119, 37);
		frame.getContentPane().add(btnCancelar);
		
		JLabel lblFondo = new JLabel("New label");
		lblFondo.setIcon(new ImageIcon(CrearLista.class.getResource("/imagenes/pexels-pixabay-415071.jpg")));
		lblFondo.setBounds(0, 0, 739, 539);
		frame.getContentPane().add(lblFondo);
		
		frame.setVisible(true);
	}
	
	public boolean comprobarElementos(String textNombre,String textAreaDescripcion) {
		return !textNombre.equals("")&&!textAreaDescripcion.equals("");
	}
}
